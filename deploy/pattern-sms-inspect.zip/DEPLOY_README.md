# Inspect next-purchase discounts via artisan (no DB client needed)

Copy InspectNextPurchaseDiscounts.php into app/Console/Commands/
Then:

php artisan optimize:clear
php artisan sms:inspect-next-purchase
php artisan sms:inspect-next-purchase --limit=50

Send the full output back.
