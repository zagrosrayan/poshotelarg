# Inspect only (no full update needed)

unzip into Laravel root, then:

php artisan optimize:clear
php artisan sms:inspect-next-purchase --limit=50
