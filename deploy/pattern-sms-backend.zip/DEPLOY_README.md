# Pattern SMS package + inspect

## Only inspect first (recommended)
php artisan optimize:clear
php artisan sms:inspect-next-purchase --limit=50

## Full deploy later
systemctl reload php8.3-fpm || systemctl reload php8.2-fpm || systemctl reload php-fpm
php artisan migrate --force --path=database/migrations/2026_07_21_173000_create_discount_sms_deliveries_table.php
php artisan migrate --force --path=database/migrations/2026_07_22_123000_add_sms_enabled_to_next_purchase_discounts_table.php
php artisan optimize:clear
