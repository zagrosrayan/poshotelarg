# Deploy: next-purchase SMS + complete capacity fix

## Includes (changed files only)
- app/Service/NextPurchaseDiscountSmsScheduler.php  (pattern vars: name;amount;date)
- app/Console/Commands/DiagnoseDiscountSms.php
- app/Models/Customer.php  (next_purchase_discount_* for checkout UI)
- app/Repository/OrderRepository.php  (allow already-reserved NP on complete)
- app/Http/Requests/CompleteOrderRequest.php
- app/Http/Controllers/OrderController.php  (complete NP lookup + sqlsrv guard for Protel SP)

## NOT included (local-only — do not copy from hotel-pos-backend-local)
- print skip / local_complete_skip_print
- empty InhouseList guest list stub
- local error message hacks

## Server steps
1. Unzip into Laravel root (/var/www/html/protel)
2. systemctl reload php8.3-fpm  (or php8.2-fpm / php-fpm)
3. php artisan optimize:clear
4. php artisan sms:diagnose
5. Optional live test: php artisan sms:diagnose --send --to=09107860475

## Verify
- grep -n "name, \, \" app/Service/NextPurchaseDiscountSmsScheduler.php
- grep -n next_purchase_discount_code app/Models/Customer.php
- grep -n allowDiscountId app/Repository/OrderRepository.php
