# جمع‌بندی اصلاحات تایید نهایی / پیش‌فاکتور
تاریخ: 2026-07-27

## ۱) چاپ مجدد بعد از تایید نهایی
- مشکل: دکمه «چاپ مجدد» فقط قبل از تکمیل سفارش دیده می‌شد و بعد از تایید نهایی مخفی بود.
- اصلاح: در `OrderInfoDisplay` بعد از وضعیت `order-status-complete` دکمه چاپ مجدد نمایش داده می‌شود.
- چاپ پیش‌فاکتور فقط قبل از تکمیل سفارش باقی ماند.

## ۲) تخفیف از تایید نهایی به پیش‌فاکتور
- مشکل: بخش انتخاب تخفیف داخل مودال تایید نهایی بود.
- اصلاح: `CheckoutDiscountSection` از `CompleteOrderModal` حذف و به `PrePrintModal` منتقل شد.
- در تایید نهایی فقط وضعیت تخفیف قبلی (خواندنی) نمایش داده می‌شود.

## ۳) غیرفعال شدن نقدی و پوز برای مهمان مقیم
- مشکل: با انتخاب مقیم، نقدی/پوز همچنان قابل انتخاب بودند.
- اصلاح: در تب مقیم/پرسنل فقط روش `payment-method-resident-user` فعال است و نقدی/پوز غیرفعال می‌شوند؛ در تب مهمان عادی بالعکس.

## ۴) سرچ شماره اتاق در تایید نهایی
- مشکل فرانت: پارامتر `room_number` ارسال می‌شد ولی بک‌اند فقط `reserve_number` می‌خواند.
- مشکل بک‌اند: فیلتر دقیق روی Room بود و جستجوی ناقص کار نمی‌کرد.
- اصلاح بک‌اند (`UserController::guestList` در backend و backend-local): پذیرش `room_number` و فیلتر LIKE روی Room و Reserve.
- اصلاح فرانت (`ResidentSelectionSection`): نرمال‌سازی ارقام فارسی، debounce، ارسال `room_number` و `reserve_number`.

## فایل‌های تغییر یافته
### Frontend (Hotel Arg Pos)
- app/components/OrderDetails/OrderInfoDisplay.tsx
- app/components/OrderDetails/CompleteOrderModal.tsx
- app/components/OrderDetails/PrePrintModal.tsx
- app/components/OrderDetails/ResidentSelectionSection.tsx
- app/v1/dashboard/orders/detail/page.tsx

### Backend
- hotel-pos-backend/app/Http/Controllers/UserController.php
- hotel-pos-backend-local/app/Http/Controllers/UserController.php
