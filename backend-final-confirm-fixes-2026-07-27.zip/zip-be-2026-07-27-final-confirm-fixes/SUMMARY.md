# Backend fixes - guest search / invoice null-safety
- guestList accepts room_number and LIKE filters Room/Reserve
- hp-invoice null-safe customer/reserve/food access
